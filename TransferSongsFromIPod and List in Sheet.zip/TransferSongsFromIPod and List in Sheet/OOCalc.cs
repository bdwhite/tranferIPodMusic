﻿/*
Author: Colin Carter
Company: Chiona Technologies LLC
Copyright 2023 Chiona Technologies LLC
License: Code Project Open License (CPOL)
Contact: cc@chionatech.com
*/

using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

using uno;
using unoidl.com.sun.star.container;
using unoidl.com.sun.star.lang;
using unoidl.com.sun.star.uno;
using unoidl.com.sun.star.frame;
using unoidl.com.sun.star.sheet;
using unoidl.com.sun.star.beans;
using unoidl.com.sun.star.table;
using unoidl.com.sun.star.text;
using unoidl.com.sun.star.util;
using unoidl.com.sun.star.awt;
using System.Collections.Generic;
using unoidl.com.sun.star.sdb;
using System.Security.Policy;
using unoidl.com.sun.star.sdbc;
using unoidl.com.sun.star.oooimprovement;

/*
https://wiki.openoffice.org/wiki/Calc/API/Programming#Introduction
*/

namespace OOCalc
{
	public class OOCalc
	{
		// These don't really need to be saved, but can come in useful as more extensive
		// OpenOffice features are accessed.
		private XComponentContext m_xComponentContext = null;
		private XMultiServiceFactory m_xMSFactory = null;
		private XComponentLoader m_xLoader = null;

		// You'll need these ones for many of your basic operations
		private XSpreadsheetDocument m_xDocument;
		private XSpreadsheet m_xSpreadsheet;
		
		/// <summary>
		/// Returns true if OpenOffice is installed, false otherwise.
		/// </summary>
		public bool bOpenOfficeInstalled
		{
			get
			{
				RegistryKey RegKey = Registry.CurrentUser.OpenSubKey( @"SOFTWARE\OpenOffice", writable: false );
				return RegKey != null;
			}
		}

		/// <summary>
		/// Starts up the OpenOffice loader - can be used to load calc, write or other OO applications.
		/// </summary>
		/// <returns>true if successful, false if not.</returns>
		public bool bStartOpenOfficeLoader()
		{
			try
			{
				if (m_xComponentContext == null)
					m_xComponentContext = uno.util.Bootstrap.bootstrap();
				if (m_xMSFactory == null)
					m_xMSFactory = (XMultiServiceFactory)m_xComponentContext.getServiceManager();
				if (m_xLoader == null)
					m_xLoader = (XComponentLoader)m_xMSFactory.createInstance( "com.sun.star.frame.Desktop" );
				return true;
			}
			catch (unoidl.com.sun.star.uno.Exception e1)
			{
				Debug.Print( e1.Message );
			}
			return false;
		}
		/// <summary>
		/// Creates a new empty spreadsheet.
		/// </summary>
		/// <returns>the reference to all of the sheets in the new workbook</returns>
		public bool bCreateWorkbook()
		{
            if (bStartOpenOfficeLoader() == false)
                return false;
			try
			{
                // See https://wiki.openoffice.org/wiki/Documentation/DevGuide/OfficeDev/Handling_Documents
                PropertyValue[] loadProps = new PropertyValue[1];
                loadProps[0] = new PropertyValue { Name = "Hidden", Value = new Any((bool)true) }; // Set Hidden property
                // XComponent xComponent =	m_xLoader.loadComponentFromURL("private:factory/scalc", "_blank", 0, new PropertyValue[0]);
				XComponent xComponent =	m_xLoader.loadComponentFromURL("private:factory/scalc", "_blank", 0, loadProps);

				m_xDocument = (XSpreadsheetDocument)xComponent;
				XSpreadsheets xSheets = m_xDocument.getSheets();

				// Get the first sheet
				XIndexAccess xIndexAccess = (XIndexAccess)xSheets;
				Any any = xIndexAccess.getByIndex(0);
				m_xSpreadsheet = (XSpreadsheet)any.Value;

				// Delete the other sheets
				xSheets.removeByName("Sheet2");
				xSheets.removeByName("Sheet3");

				// Rename the sheet
				XNamed sheetName = (XNamed)m_xSpreadsheet;
				sheetName.setName("Songs from iPod");

				return true;
			}
            catch (unoidl.com.sun.star.uno.Exception e)
            {
                Debug.Print(e.Message);
            }
            return false;
        }
        /// <summary>
        /// Open an OpenOffice Calc workbook / document.
        /// </summary>
        /// <param name="strPath">Fully qualified path to file to open.</param>
        /// <returns>true if successful, false if not.</returns>
        public bool bOpenWorkbook( string strPath )
		{
			// Check if path exists and OpenOffice is running
			if (File.Exists( strPath ) == false || bStartOpenOfficeLoader() == false)
				return false;

			// https://wiki.openoffice.org/wiki/Documentation/DevGuide/Spreadsheets/Handling_Spreadsheet_Documents_Files
			// https://wiki.openoffice.org/wiki/Documentation/DevGuide/OfficeDev/Handling_Documents

			// Need to convert file path into URL
			string strUrl = strPathToURL( strPath );
			XComponent xComponent = m_xLoader.loadComponentFromURL( strUrl, 
																	TargetFrameName: "_blank", 
																	SearchFlags: 0, 
																	Arguments: new PropertyValue[0] );
			m_xDocument = (XSpreadsheetDocument)xComponent;
			XSpreadsheets xSheets = m_xDocument.getSheets();
			XIndexAccess xSheetsIA = (XIndexAccess)xSheets;
			m_xSpreadsheet = (XSpreadsheet)xSheetsIA.getByIndex( 0 ).Value;
			return true;
		}
		/// <summary>
		/// Lookup a cell by name (e.g. "A1" or named cell) and return XCell object.
		/// </summary>
		/// <param name="strCellName"></param>
		/// <returns>An instance of XCell object if successful, null if not.</returns>
		private XCell xGetXCellByName(string strCellName )
		{
			try
			{
				XCellRange xCR = m_xSpreadsheet.getCellRangeByName( strCellName );
				XCell xCell = xCR.getCellByPosition( nColumn: 0, nRow: 0 );
				return xCell;
			}
			catch (unoidl.com.sun.star.uno.Exception e)
			{
				Debug.Print( e.Message );
			}
			return null;
		}
		/// <summary>
		/// Sets a double value in a cell.
		/// </summary>
		/// <param name="strCellName">Name of cell to set.</param>
		/// <param name="dValue">Value to set</param>
		/// <returns>true</returns>
		public bool bSetValue( string strCellName, double dValue )
		{
			XCell xCell = xGetXCellByName( strCellName );
			xCell.setValue( dValue );
			return true;
		}
		public bool bSetFormula( string strCellName, string strFormula )
		{
			XCell xCell = xGetXCellByName( strCellName );
			xCell.setFormula( strFormula );
			return true;
		}
		/// <summary>
		/// Set text value of a cell
		/// </summary>
		/// <param name="strCellName">Name of cell to set.</param>
		/// <param name="strText">Text to set in cell.</param>
		/// <returns>true</returns>
		public bool bSetText( string strCellName, string strText )
		{
			XCell xCell = xGetXCellByName( strCellName );
			XSimpleText xST = (XSimpleText)xCell;
			XTextCursor xCursor = xST.createTextCursor();
			xST.insertString( xCursor, strText, bAbsorb: false );
			return true;
		}
		/// <summary>
		/// Set a plain date in a cell (i.e. no time).
		/// </summary>
		/// <param name="strCellName">Name of cell to set.</param>
		/// <param name="nDay">Day of year.</param>
		/// <param name="nMonth">Month of year.</param>
		/// <param name="nYear">Year.</param>
		/// <returns>true</returns>
		public bool bSetDate( string strCellName, int nYear, int nMonth, int nDay )
		{
			// Set the date value.
			XCell xCell = xGetXCellByName( strCellName );
			System.DateTime dt = new System.DateTime(nYear, nMonth, nDay);
			string strDateStr = dt.ToString( "M/dd/yyyy" );

			// You can also set "text" using the setFormula method
			xCell.setFormula( strDateStr );

			// Set date format.
			XNumberFormatsSupplier xFormatsSupplier = (XNumberFormatsSupplier)m_xDocument;
			XNumberFormatTypes xFormatTypes = (XNumberFormatTypes)xFormatsSupplier.getNumberFormats();
			int nFormat = xFormatTypes.getStandardFormat( NumberFormat.DATE, new Locale() );

			XPropertySet xPropSet = (XPropertySet)xCell;
			xPropSet.setPropertyValue( "NumberFormat", new Any( nFormat ) );
			return true;
		}
		/// <summary>
		/// Set the background color of a cell.
		/// </summary>
		/// <param name="strCellName">Name of cell to set.</param>
		/// <param name="clr">System.Drawing.color</param>
		/// <returns></returns>
		public bool bSetBackgroundColor( string strCellName, Color clr )
		{
			XCell xCell = xGetXCellByName( strCellName );
			XPropertySet xPropSet = (XPropertySet)xCell;
			UInt32 unClr = (UInt32)clr.R << 16 | (UInt32)clr.G << 8 | (UInt32)clr.B;
			xPropSet.setPropertyValue( "CellBackColor", new Any( unClr ) );
			return true;
		}

		// https://wiki.openoffice.org/wiki/Documentation/DevGuide/Spreadsheets/Saving_Spreadsheet_Documents
		// https://wiki.documentfoundation.org/Documentation/DevGuide/Office_Development#Handling_Documents
		/// <summary>
		/// Save the workbook, optionally specifying a file path. If file path is specified, tries
		/// to save to that path. If file path is empty, but file has been saved before, will save
		/// to the previous filepath. If file path is empty and file hasn't been saved yet, will
		/// prompt for a new file path and save to that.
		/// </summary>
		/// <param name="strFilePath">File path to save to. Can be empty or null.</param>
		/// <returns>The file path saved to or string.Empty if not saved.</returns>
		public string strSaveWorkbook( string strFilePath = null )
		{
			XStorable xStorable = (XStorable)m_xDocument;
			string strFileURL = string.Empty;

			// If we don't have a file path passed in, check if the file has
			// been previously saved. If so, use that file name
			if (string.IsNullOrEmpty( strFilePath ))
			{
				// If we already have a file path, use it
				if (xStorable.hasLocation())
				{
					strFileURL = xStorable.getLocation();
					strFilePath = strUrlToPath( strFileURL );
				}
				// Otherwise prompt for one
				else
				{
					SaveFileDialog sfd = new SaveFileDialog();
					sfd.Filter = "ODF Spreadsheet (*.odf)|*.odf";
					DialogResult dr = sfd.ShowDialog();
					if (dr == DialogResult.Cancel)
						return String.Empty;
					strFilePath = sfd.FileName;
				}
			}
			if ( string.IsNullOrEmpty( strFileURL ) )
				strFileURL = strPathToURL( strFilePath );
			
			// Save with no args for default file format
			xStorable.storeAsURL( strFileURL, new PropertyValue[0] );
			return strFilePath;
		}
		/// <summary>
		///  Save an already saved file in Excel97 format.
		/// </summary>
		/// <returns>The file path saved to or string.Empty if not saved.</returns>
		public string strSaveWorkbookAsExcel()
		{
			XStorable xStorable = (XStorable)m_xDocument;

			if (xStorable.hasLocation() == false)
				return string.Empty;

			string strFileURL = xStorable.getLocation(),
				strFilePath = strUrlToPath( strFileURL );

			PropertyValue[] apv = new PropertyValue[1];
			apv[0] = new PropertyValue();
			apv[0].Name = "FilterName";
			apv[0].Value = new Any( "MS Excel 97" );
			strFilePath = Path.ChangeExtension( strFilePath, "xls" );
			strFileURL = strPathToURL(strFilePath );
			xStorable.storeAsURL( strFileURL, apv );
			return strFilePath;
		}
		/// <summary>
		/// Close the current workbook.
		/// </summary>
		/// <returns>true</returns>
		public bool bCloseWorkbook()
		{
			if (m_xDocument != null)
			{
				XComponent xComponent = (XComponent)m_xDocument;
				xComponent.dispose();
			}
			return true;
		}
		/// <summary>
		/// Convert a Windows filepath to URL style required by OpenOffice.
		/// </summary>
		/// <param name="strFilePath">Windows file path to convert.</param>
		/// <returns>string containing new file path in URL format.</returns>
		private string strPathToURL( string strFilePath ) // fully qualified file path
		{
			string strURL = "file:///" + strFilePath.Replace( "\\", "/" );
			return strURL;
		}
		/// <summary>
		/// Convert an OpenOffice URL to Windows file path.
		/// </summary>
		/// <param name="strFileURL">OO URL to convert.</param>
		/// <returns>String containing the Windows file path.</returns>
		private string strUrlToPath( string strFileURL )
		{
			string strFilePath = strFileURL;
			if (strFileURL.Substring( 0, 8 ) == "file:///")
				strFilePath = strFileURL.Substring( 8 );
			strFilePath = strFilePath.Replace( "/", "\\" );
			return strFilePath;
		}
        public bool bSetBoldFontStyle(string strCellName)
        {
            XCell xCell = xGetXCellByName(strCellName);
            XPropertySet xPropSet = (XPropertySet)xCell;
            xPropSet.setPropertyValue("CharWeight", new Any(FontWeight.BOLD));
            return true;
        }
        public bool bCenterText(string strCellName)
        {
            XCell xCell = xGetXCellByName(strCellName);
            XPropertySet xPropSet = (XPropertySet)xCell;
            xPropSet.setPropertyValue("HoriJustify", new Any((byte)CellHoriJustify.CENTER));
            return true;
        }
        public bool bSetColumnWidth(string strColumnLetter)
        {
            XCellRange Range = null;
            Range = m_xSpreadsheet.getCellRangeByName(strColumnLetter + "1"); //Recover the range, a cell is 

            XColumnRowRange RCol = (XColumnRowRange)Range; //Creates a collar ranks 
            XTableColumns LCol = RCol.getColumns(); // Retrieves the list of passes
            uno.Any Col = LCol.getByIndex(0); //Extract the first Col

            XPropertySet xPropSet = (XPropertySet)Col.Value;
            xPropSet.setPropertyValue("OptimalWidth", new Any((bool)true));
            return true;
        }
		public bool underlineCell(string sRange)
        {
            // Draw bottom border
            XCellRange xCellRange = m_xSpreadsheet.getCellRangeByName(sRange);
            XPropertySet xPropSet = (XPropertySet)xCellRange;
            BorderLine aLine = new BorderLine();
			// aLine.Color = 0x99CCFF;
			aLine.Color = 0x000000;
            aLine.InnerLineWidth = aLine.LineDistance = 0;
            // aLine.OuterLineWidth = 100;
            aLine.OuterLineWidth = 50;
            TableBorder aBorder = new TableBorder();
            aBorder.TopLine = aBorder.BottomLine = aBorder.LeftLine = aBorder.RightLine = aLine;
            aBorder.IsTopLineValid = aBorder.IsBottomLineValid = true;
            aBorder.IsLeftLineValid = aBorder.IsRightLineValid = false;
            xPropSet.setPropertyValue("TableBorder", new Any(typeof(TableBorder), aBorder));

			return true;
        }
		public bool renameTab(string tabName)
		{
            XNamed xPageName = (XNamed)m_xSpreadsheet;
            xPageName.setName(tabName);

            return true;
        }
    }
}
