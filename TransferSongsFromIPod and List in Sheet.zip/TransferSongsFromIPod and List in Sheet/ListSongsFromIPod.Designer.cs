﻿namespace TransferSongsFromIPod_and_List_in_Sheet
{
    partial class ListSongsFromIPod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStart = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.lblSongs = new System.Windows.Forms.Label();
            this.txtSongs = new System.Windows.Forms.TextBox();
            this.cboxRemovableDrives = new System.Windows.Forms.ComboBox();
            this.lblDriveSelected = new System.Windows.Forms.Label();
            this.pBar = new System.Windows.Forms.ProgressBar();
            this.txtHeader = new System.Windows.Forms.TextBox();
            this.radioExcel = new System.Windows.Forms.RadioButton();
            this.radioCalc = new System.Windows.Forms.RadioButton();
            this.lblSelectSheetProgram = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(80, 170);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Visible = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnQuit.Location = new System.Drawing.Point(133, 170);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(75, 23);
            this.btnQuit.TabIndex = 1;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // lblSongs
            // 
            this.lblSongs.AutoSize = true;
            this.lblSongs.Location = new System.Drawing.Point(13, 87);
            this.lblSongs.Name = "lblSongs";
            this.lblSongs.Size = new System.Drawing.Size(124, 13);
            this.lblSongs.TabIndex = 2;
            this.lblSongs.Text = "Songs Being Transferred";
            this.lblSongs.Visible = false;
            // 
            // txtSongs
            // 
            this.txtSongs.Location = new System.Drawing.Point(13, 104);
            this.txtSongs.Name = "txtSongs";
            this.txtSongs.Size = new System.Drawing.Size(434, 20);
            this.txtSongs.TabIndex = 3;
            this.txtSongs.Visible = false;
            // 
            // cboxRemovableDrives
            // 
            this.cboxRemovableDrives.FormattingEnabled = true;
            this.cboxRemovableDrives.Location = new System.Drawing.Point(190, 140);
            this.cboxRemovableDrives.Name = "cboxRemovableDrives";
            this.cboxRemovableDrives.Size = new System.Drawing.Size(121, 21);
            this.cboxRemovableDrives.TabIndex = 4;
            this.cboxRemovableDrives.Visible = false;
            // 
            // lblDriveSelected
            // 
            this.lblDriveSelected.AutoSize = true;
            this.lblDriveSelected.Location = new System.Drawing.Point(24, 143);
            this.lblDriveSelected.Name = "lblDriveSelected";
            this.lblDriveSelected.Size = new System.Drawing.Size(165, 13);
            this.lblDriveSelected.TabIndex = 5;
            this.lblDriveSelected.Text = "Select drive assigned to the iPod:";
            this.lblDriveSelected.Visible = false;
            // 
            // pBar
            // 
            this.pBar.Location = new System.Drawing.Point(16, 37);
            this.pBar.Name = "pBar";
            this.pBar.Size = new System.Drawing.Size(309, 23);
            this.pBar.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.pBar.TabIndex = 6;
            this.pBar.Visible = false;
            // 
            // txtHeader
            // 
            this.txtHeader.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtHeader.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHeader.ForeColor = System.Drawing.Color.IndianRed;
            this.txtHeader.Location = new System.Drawing.Point(16, 21);
            this.txtHeader.Multiline = true;
            this.txtHeader.Name = "txtHeader";
            this.txtHeader.Size = new System.Drawing.Size(309, 40);
            this.txtHeader.TabIndex = 7;
            this.txtHeader.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtHeader.Visible = false;
            // 
            // radioExcel
            // 
            this.radioExcel.AutoSize = true;
            this.radioExcel.Location = new System.Drawing.Point(80, 67);
            this.radioExcel.Name = "radioExcel";
            this.radioExcel.Size = new System.Drawing.Size(51, 17);
            this.radioExcel.TabIndex = 8;
            this.radioExcel.TabStop = true;
            this.radioExcel.Text = "Excel";
            this.radioExcel.UseVisualStyleBackColor = true;
            this.radioExcel.CheckedChanged += new System.EventHandler(this.radioExcel_CheckedChanged);
            // 
            // radioCalc
            // 
            this.radioCalc.AutoSize = true;
            this.radioCalc.Location = new System.Drawing.Point(180, 67);
            this.radioCalc.Name = "radioCalc";
            this.radioCalc.Size = new System.Drawing.Size(103, 17);
            this.radioCalc.TabIndex = 9;
            this.radioCalc.TabStop = true;
            this.radioCalc.Text = "OpenOffice Calc";
            this.radioCalc.UseVisualStyleBackColor = true;
            this.radioCalc.CheckedChanged += new System.EventHandler(this.radioCalc_CheckedChanged);
            // 
            // lblSelectSheetProgram
            // 
            this.lblSelectSheetProgram.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectSheetProgram.ForeColor = System.Drawing.Color.IndianRed;
            this.lblSelectSheetProgram.Location = new System.Drawing.Point(12, 5);
            this.lblSelectSheetProgram.Name = "lblSelectSheetProgram";
            this.lblSelectSheetProgram.Size = new System.Drawing.Size(313, 23);
            this.lblSelectSheetProgram.TabIndex = 10;
            this.lblSelectSheetProgram.Text = "Select the spreadsheet program to use";
            this.lblSelectSheetProgram.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ListSongsFromIPod
            // 
            this.AcceptButton = this.btnStart;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.CancelButton = this.btnQuit;
            this.ClientSize = new System.Drawing.Size(337, 214);
            this.ControlBox = false;
            this.Controls.Add(this.lblSelectSheetProgram);
            this.Controls.Add(this.radioCalc);
            this.Controls.Add(this.radioExcel);
            this.Controls.Add(this.txtHeader);
            this.Controls.Add(this.pBar);
            this.Controls.Add(this.lblDriveSelected);
            this.Controls.Add(this.cboxRemovableDrives);
            this.Controls.Add(this.txtSongs);
            this.Controls.Add(this.lblSongs);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnStart);
            this.Name = "ListSongsFromIPod";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Transfer Songs From iPod and List in a Spreadsheet";
            this.Load += new System.EventHandler(this.ListSongsFromIPod_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Label lblSongs;
        private System.Windows.Forms.TextBox txtSongs;
        private System.Windows.Forms.ComboBox cboxRemovableDrives;
        private System.Windows.Forms.Label lblDriveSelected;
        private System.Windows.Forms.ProgressBar pBar;
        private System.Windows.Forms.TextBox txtHeader;
        private System.Windows.Forms.RadioButton radioExcel;
        private System.Windows.Forms.RadioButton radioCalc;
        private System.Windows.Forms.Label lblSelectSheetProgram;
    }
}

