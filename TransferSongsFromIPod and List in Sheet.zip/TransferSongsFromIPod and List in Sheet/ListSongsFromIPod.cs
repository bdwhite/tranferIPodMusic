﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using Microsoft.Office.Interop.Excel;
using unoidl.com.sun.star.sheet;
using System.Windows.Forms;
using System.Management;
using System.Reflection;
using Action = System.Action;
using System.ComponentModel;
using unoidl.com.sun.star.lang;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;

namespace TransferSongsFromIPod_and_List_in_Sheet
{
    public partial class ListSongsFromIPod : Form
    {
        public string msg = string.Empty;
        public string title = string.Empty;

        public ListSongsFromIPod()
        {
            InitializeComponent();
        }

        private async void btnStart_Click(object sender, EventArgs e)
        {
            int row = 2;
            int col = 65;
            string curDate = System.DateTime.Now.ToString("MM-dd-yyyy");
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            string msg = string.Empty;
            string appName = string.Empty;
            string sourceFolder = string.Empty;
            string destFolder = string.Empty;
            string namePart = string.Empty;
            string ext = string.Empty;
            string newNameOfSong = string.Empty;
            string sheetName = string.Empty;
            List<string> removableDrives = new List<string>();
            List<string> iPodSongs = new List<string>();

            if (btnStart.Text == "Continue")
            {
                // Hide the drive selection for the iPod
                lblDriveSelected.Visible = false;
                cboxRemovableDrives.Visible = false;

                // Make visible the section to show the progress
                lblSongs.Visible = true;
                txtSongs.Visible = true;

                // Change the header
                txtHeader.Text = "Now wait, tranferring the songs...";
                // Now, search that drive for the files
                string item = cboxRemovableDrives.SelectedItem.ToString();
                sourceFolder = cboxRemovableDrives.SelectedItem.ToString() + "iPod_Control\\Music\\";
                // See if there is an iPod assigned to the selected drive

                if (!Directory.Exists(sourceFolder))
                {
                    msg = "It does not appear that this drive contains valid music files!\n\nRe-run this program to select the correct drive that the iPod has been assigned to.\n\n\nClick on OK to quit.";
                    title = "iPod Not Detected";
                    ShowMessage(msg, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    // Exit the program
                    this.Close();

                }

                // Bring up the dialog box so the user can select where the iPod songs are to be stored
                folderDlg = new FolderBrowserDialog();
                folderDlg.ShowNewFolderButton = true;
                folderDlg.Description = "Select the folder where the spreadsheet and the analyzed files are to be stored";
                // Show the FolderBrowserDialog  
                DialogResult result = folderDlg.ShowDialog();
                if (folderDlg.SelectedPath == string.Empty)
                {
                    msg = "No folder was selected!\n\nRe-run this program to select a folder.\n\n\nClick on OK to quit.";
                    ShowMessage(msg, "Valid Destination Folder Check", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    // Exit the program
                    this.Close();

                }
                else
                {
                    // Get all of the songs in that folder and store them in an array
                    iPodSongs = getAllSongs(sourceFolder);

                    // Store the destination folder
                    destFolder = folderDlg.SelectedPath;

                    // Find out which type of spreadsheet to use
                    if (radioCalc.Checked)
                    {
                        appName = radioCalc.Name;
                        // Create a new Calc instance
                        OOCalc.OOCalc ooCalc = new OOCalc.OOCalc();
                        ooCalc.bStartOpenOfficeLoader();
                        ooCalc.bCreateWorkbook();

                        // Set the headers
                        ooCalc.bSetText("A1", "Title");
                        ooCalc.bSetText("B1", "Artist");
                        ooCalc.bSetText("C1", "Album");
                        ooCalc.bSetText("D1", "Song Length");

                        // Change the font to bold
                        ooCalc.bSetBoldFontStyle("A1");
                        ooCalc.bSetBoldFontStyle("B1");
                        ooCalc.bSetBoldFontStyle("C1");
                        ooCalc.bSetBoldFontStyle("D1");

                        // Center the cell
                        ooCalc.bCenterText("A1");
                        ooCalc.bCenterText("B1");
                        ooCalc.bCenterText("C1");
                        ooCalc.bCenterText("D1");

                        // Underline the cells
                        ooCalc.underlineCell("A1");
                        ooCalc.underlineCell("B1");
                        ooCalc.underlineCell("C1");
                        ooCalc.underlineCell("D1");

                        // Rename the tab
                        ooCalc.renameTab("Songs from iPod");

                        // Make visible the controls on the form
                        lblSongs.Visible = true;
                        lblSongs.Refresh();
                        txtSongs.Visible = true;
                        txtSongs.Refresh();

                        // Hide the buttons
                        btnStart.Visible = false;
                        btnQuit.Visible = false;

                        // Get the song info
                        foreach (string nameOfSong in iPodSongs)
                        {
                            try
                            {
                                TagLib.File tfile = TagLib.File.Create(nameOfSong);

                                string[] Performers = tfile.Tag.Performers;

                                // Add this to the sheet
                                ooCalc.bSetText((char)col + row.ToString(), tfile.Tag.Title);

                                // Update the screen to show which song is being processed
                                txtSongs.Text = tfile.Tag.Title + " by " + getStringFromArray(Performers);
                                txtSongs.Refresh();

                                col++;
                                ooCalc.bSetText((char)col + row.ToString(), getStringFromArray(Performers));
                                col++;
                                ooCalc.bSetText((char)col + row.ToString(), tfile.Tag.Album);
                                col++;
                                ooCalc.bSetText((char)col + row.ToString(), tfile.Properties.Duration.Minutes.ToString() + ":" + convertToTwoDigits(tfile.Properties.Duration.Seconds.ToString()));

                                // Save the file in the destination folder
                                // Get the file info
                                FileInfo iPodSong = new FileInfo(nameOfSong);
                                namePart = Path.GetFileNameWithoutExtension(iPodSong.Name);
                                ext = iPodSong.Extension.ToString();
                                newNameOfSong = removeInvalidChars(tfile.Tag.Title) + ext;
                                System.IO.File.Copy(nameOfSong, destFolder + "\\" + newNameOfSong, true);

                                row++;
                                if (row > 10)
                                {
                                    break;
                                }
                                // Reset the column for the next row
                                col = 65;
                            }
                            catch
                            {
                                msg = "It does not appear that these are valid music files!\n\nRe-run this program to select the hidden folder on the iPod named 'iPod_Control\\Music'.\n\n\nClick on OK to quit.";
                                ShowMessage(msg, "Invalid Music Files Check", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                // Exit the program
                                this.Close();
                            }
                        }
                        if (msg.IndexOf("invalid music") == -1)
                        {
                            // Set the optimum width for each column
                            ooCalc.bSetColumnWidth("A");
                            ooCalc.bSetColumnWidth("B");
                            ooCalc.bSetColumnWidth("C");
                            ooCalc.bSetColumnWidth("D");

                            // Save the workbook
                            sheetName = "iPod Songs as of " + curDate + ".ods";
                            ooCalc.strSaveWorkbook(destFolder + "\\" + sheetName);
                            this.TopMost = true;
                            msg = "All of the songs from the iPod have been analyzed and stored in the sheet.\n\nThe sheet was saved in '" + destFolder + "' and named '" + sheetName + "'.\n\nThe songs were saved in '" + destFolder + "' using their Title with an extension of MP3.\n\n\nClick on OK to quit.";
                            ShowMessage(msg, "Process Completion Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        // Close the workbook
                        ooCalc.bCloseWorkbook();
                    }
                    else
                    {
                        // Excel chosen
                        appName = radioCalc.Name;
                        _Application oXL;
                        _Workbook oWB;
                        _Worksheet oSheet;
                        Range borderRange;

                        // Start Excel and get Application object
                        oXL = new Microsoft.Office.Interop.Excel.Application();
                        oXL.Visible = false;

                        // Create a workbook
                        oWB = oXL.Workbooks.Add();

                        // Point to the first sheet
                        oSheet = oWB.Sheets[1];

                        // Add the headers
                        oSheet.Cells[1, 1] = "Title";
                        oSheet.Cells[1, 2] = "Artist";
                        oSheet.Cells[1, 3] = "Album";
                        oSheet.Cells[1, 4] = "Song Length";

                        // Make them bold and center them
                        for (int i = 1; i < 5; i++)
                        {
                            oSheet.Cells[1, i].Font.Bold = true;
                            oSheet.Cells[1, i].HorizontalAlignment = XlHAlign.xlHAlignCenter;
                        }

                        // Add the bottom border
                        borderRange = oSheet.Range[oSheet.Cells[1, 1], oSheet.Cells[1, 4]];
                        borderRange.Borders[XlBordersIndex.xlEdgeBottom].LineStyle = XlLineStyle.xlContinuous;

                        // Rename the tab
                        oSheet.Name = "Songs From iPod";

                        // Get the song info
                        foreach (string nameOfSong in iPodSongs)
                        {
                            TagLib.File tfile = TagLib.File.Create(nameOfSong);

                            string[] Performers = tfile.Tag.Performers;

                            // Add this to the sheet
                            oSheet.Cells[row, 1] = tfile.Tag.Title;

                            // Update the screen to show which song is being processed
                            txtSongs.Text = tfile.Tag.Title + " by " + getStringFromArray(Performers);
                            txtSongs.Refresh();

                            oSheet.Cells[row, 2] = getStringFromArray(Performers);
                            oSheet.Cells[row, 3] = tfile.Tag.Album;
                            oSheet.Cells[row, 4] = tfile.Properties.Duration.Minutes.ToString() + ":" + convertToTwoDigits(tfile.Properties.Duration.Seconds.ToString());

                            // Save the file in the destination folder
                            // Get the file info
                            FileInfo iPodSong = new FileInfo(nameOfSong);
                            namePart = Path.GetFileNameWithoutExtension(iPodSong.Name);
                            ext = iPodSong.Extension.ToString();
                            newNameOfSong = removeInvalidChars(tfile.Tag.Title) + ext;
                            System.IO.File.Copy(nameOfSong, destFolder + "\\" + newNameOfSong, true);

                            // Increment the row
                            row++;
                            if (row > 10)
                            {
                                break;
                            }

                            // Reset the column for the next row
                            col = 65;
                        }
                        // AutoFit columns to fit content
                        oSheet.Columns.AutoFit();

                        // Save the workbook
                        sheetName = "iPod Songs as of " + curDate + ".xlsx";
                        oWB.SaveAs(destFolder + "\\" + sheetName);

                        this.TopMost = true;
                        msg = "All of the songs from the iPod have been analyzed and stored in the sheet.\n\nThe sheet was saved in '" + destFolder + "' and named '" + sheetName + "'.\n\nThe songs were saved in '" + destFolder + "' using their Title with an extension of MP3.\n\n\nClick on OK to quit.";
                        ShowMessage(msg, "Process Completion Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Close and release resources
                        oWB.Close(true);
                        oXL.Quit();
                    }

                    // Exit the program
                    this.Close();
                }
            }
            else
            {
                // Define the variable to test for the timeout
                bool timeoutOccurred = false;

                // Reposition everything
                this.Size = new Size(487, 364);
                btnStart.Location = new System.Drawing.Point(109, 207);
                btnQuit.Location = new System.Drawing.Point(268, 207);
                lblSongs.Location = new System.Drawing.Point(13, 87);
                txtSongs.Location = new System.Drawing.Point(13, 104);
                txtHeader.Visible = false;

                // Hide the buttons while waiting
                btnQuit.Visible = false;
                btnStart.Visible = false;


                // See if an iPod is already plugged in
                removableDrives = driveLocationOfDevice();
                if (removableDrives.Count == 0)
                {
                    lblSelectSheetProgram.Text = "Waiting for iPod to be inserted...";

                    // Show the Progress Bar
                    pBar.Visible = true;

                    // Wait for a USB device to be plugged in
                    await Task.Run(() =>
                    {
                        var doneEvent = new AutoResetEvent(false);
                        ManagementEventWatcher watcher = new ManagementEventWatcher();
                        WqlEventQuery query2 = new WqlEventQuery("SELECT * FROM __InstanceCreationEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_USBControllerDevice'");
                        // watcher.EventArrived += new EventArrivedEventHandler(USBInserted);
                        watcher.Options.Timeout = new TimeSpan(0, 0, 0, 30);
                        watcher.Query = query2;
                        watcher.Start();
                        try
                        {
                            watcher.WaitForNextEvent();
                        }
                        catch
                        {
                            timeoutOccurred = true;
                        }
                    });
                    if (timeoutOccurred)
                    {
                        ShowMessage("Waited for 30 seconds - no USB device has been plugged in!\n\nThis program will now exit.", "No iPod Detected", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        this.Close();
                    }
                    else
                    {
                        // Wait for 5 seconds for the system to recognize the iPod
                        Thread.Sleep(TimeSpan.FromSeconds(5));
                        // Find the drive the iPod is on
                        removableDrives = driveLocationOfDevice();
                        if (removableDrives.Count == 0)
                        {
                            msg = "There are no iPods inserted!\n\nThis program will now exit.";
                            title = "No iPod Was Detected!!!";
                            ShowMessage(msg, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            // Exit the program
                            this.Close();

                        }
                    }
                }
                else
                {
                    // Find the drive the iPod is on
                    removableDrives = driveLocationOfDevice();

                    if (removableDrives.Count == 0)
                    {
                        msg = "There are no iPods inserted!\n\nThis program will now exit.";
                        title = "No iPod Was Detected!!!";
                        ShowMessage(msg, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                if (removableDrives.Count > 0)
                {
                    // Populate the combo box
                    BindingSource bindSrce = new BindingSource();
                    bindSrce.DataSource = removableDrives;
                    cboxRemovableDrives.DataSource = bindSrce;

                    // Make it visible
                    lblDriveSelected.Visible = true;
                    cboxRemovableDrives.Visible = true;

                    // Re-postion the spreadsheet selection label
                    lblSelectSheetProgram.Location = new System.Drawing.Point(12, 5);

                    // Re-postion the header
                    txtHeader.Location = new System.Drawing.Point(16, 30);
                    // Re-size it
                    txtHeader.Size = new Size(353, 40);
                    
                    // Set the text of the header
                    txtHeader.Text = "Now ready to transfer the songs off the iPod.";
                    txtHeader.AppendText(Environment.NewLine);
                    txtHeader.AppendText("Click on 'Continue' to proceed.");
                    txtHeader.Visible = true;
                    // Make the buttons visible
                    btnQuit.Visible = true;
                    btnStart.Visible = true;
                    // Rename the start button
                    btnStart.Text = "Continue";
                }
                else
                {
                    // Exit the program
                    this.Close();
                }
            }
        }
        private string convertToTwoDigits(string timeValue)
        {
            string outputString = string.Empty;

            if (timeValue.Length == 1)
            {
                outputString = "0" + timeValue;
            }
            else
            {
                outputString = timeValue;
            }

            return outputString;
        }
        private string removeInvalidChars(string nameOfFile)
        {
            return string.Join("_", nameOfFile.Split(Path.GetInvalidFileNameChars()));
        }
        private bool isOfficeInstalled()
        {
            bool isInstalled = false;
            RegistryKey officeKey = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Office");
            if (officeKey != null)
            {
                isInstalled = true;
            }

            return isInstalled;
        }
        private string getStringFromArray(string[] inputArray)
        {
            string outputString = "";

            if (inputArray.Length > 0)
            {
                foreach (string item in inputArray)
                {
                    outputString = item + ",";
                }

                // Strip off the trailing string
                outputString = outputString.Substring(0, outputString.Length - 1);
            }

            return outputString;
        }
        private List<string> getAllRemovableDrives()
        {
            List<string> allDrivesFound = new List<string>();
            foreach (DriveInfo drive in DriveInfo.GetDrives())
            {
                if (drive.DriveType == DriveType.Removable)
                {
                    allDrivesFound.Add(drive.Name);
                }
            }
            return allDrivesFound;
        }
        private void btnQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void radioExcel_CheckedChanged(object sender, EventArgs e)
        {
            if (radioExcel.Checked)
            {
                if (!(isOfficeInstalled()))
                {
                    msg = "Microsoft Office is NOT installed on this computer!\n\nThis program will now exit.";
                    title = "Microsoft Office Installation Check";
                    ShowMessage(msg, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    // Exit the program
                    this.Close();

                }
                else
                {
                    // Clear the text first
                    lblSelectSheetProgram.Text = string.Empty; 
                    lblSelectSheetProgram.Text = radioExcel.Text + " is the selected output format.";
                    showButtons();
                }
            }
        }

        private void radioCalc_CheckedChanged(object sender, EventArgs e)
        {
            if (radioCalc.Checked)
            {
                if (!(isOpenOfficeInstalled()))
                {
                    msg = "OpenOffice is NOT installed on this computer!\n\nThis program will now exit.";
                    title = "OpenOffice Installation Check";
                    ShowMessage(msg, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    // Exit the program
                    this.Close();

                }
                else
                {
                    // Clear the text first
                    lblSelectSheetProgram.Text = string.Empty;
                    lblSelectSheetProgram.Text = "Open Office is the selected output format.";
                    showButtons();
                }
            }
        }
        private void showButtons()
        {
            // Show start button
            btnStart.Visible = true;
            // Re-locate the quit button
            btnQuit.Location = new System.Drawing.Point(190, 170);
            txtHeader.Visible = true;
            radioCalc.Visible = false;
            radioExcel.Visible = false;
        }
        private void ShowMessage(string msg, string title, MessageBoxButtons buttonsToDisplay, MessageBoxIcon iconToDisplay)
        {
            this.Visible = false;
            MessageBox.Show(msg, title, buttonsToDisplay, iconToDisplay);
        }
        private bool isOpenOfficeInstalled()
        {
            bool isInstalled = false;
            RegistryKey openOfficeKey = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\OpenOffice");
            if (openOfficeKey != null)
            {
                isInstalled = true;
            }

            return isInstalled;
        }
        private List<string> getAllSongs(string sourceFolder)
        {
            List<string> iPodSongsFound = new List<string>();

            DirectoryInfo d = new DirectoryInfo(sourceFolder);
            foreach (DirectoryInfo dInfo in d.GetDirectories())
            {
                // Store all of the songs in each folder
                foreach (FileInfo f in dInfo.GetFiles("*.*"))
                {
                    iPodSongsFound.Add(dInfo.FullName + "\\" + f.ToString());
                }
            }

            return iPodSongsFound;
        }
        private List<string> driveLocationOfDevice()
        {
            List<string> allRemovableDrives = new List<string>();
            List<string> iPodLocation = new List<string>();
            // Get a list of all removable drives
            allRemovableDrives = getAllRemovableDrives();
            if (allRemovableDrives.Count > 0)
            {
                foreach (string drive in allRemovableDrives)
                {
                    if (Directory.Exists(drive + "\\" + "iPod_Control\\Music\\"))
                    {
                        iPodLocation.Add(drive + "\\");
                    }
                }
            }

            return iPodLocation;
        }

        private void ListSongsFromIPod_Load(object sender, EventArgs e)
        {
            // Insert the version number
            Assembly assembly = Assembly.GetExecutingAssembly();
            FileVersionInfo fileVersionInfo = FileVersionInfo.GetVersionInfo(assembly.Location);
            this.Text += " - v" + fileVersionInfo.ProductVersion;
        }
    }
}
